// Lista global para armazenar todos os Pokémon
let allPokemon = [];

// Função para alternar entre as abas
function showTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    document.getElementById(tabId).classList.add('active');
}

// Função assíncrona para buscar todos os Pokémon
async function fetchAllPokemon() {
    const limit = 100; // Número de Pokémon por requisição
    const total = 898; // Total de Pokémon até a 8ª geração
    const pokemonList = [];

    for (let offset = 0; offset < total; offset += limit) {
        const url = `https://pokeapi.co/api/v2/pokemon?limit=${limit}&offset=${offset}`;
        try {
            const response = await fetch(url);
            const data = await response.json();
            pokemonList.push(...data.results);
        } catch (error) {
            console.error('Failed to fetch Pokémon list:', error);
        }
    }

    allPokemon = pokemonList.sort((a, b) => a.name.localeCompare(b.name));
    await fetchAllTypes(); // Carrega os tipos
    displayPokemonCatalog(allPokemon); // Exibe o catálogo
}

// Função para buscar todos os tipos de Pokémon
async function fetchAllTypes() {
    const url = `https://pokeapi.co/api/v2/type`;
    try {
        const response = await fetch(url);
        const data = await response.json();
        const typeFilter = document.getElementById('typeFilter');
        data.results.forEach(type => {
            const option = document.createElement('option');
            option.value = type.name;
            option.textContent = type.name.charAt(0).toUpperCase() + type.name.slice(1);
            typeFilter.appendChild(option);
        });
    } catch (error) {
        console.error('Failed to fetch Pokémon types:', error);
    }
}

// Função para filtrar Pokémon por tipo
async function filterPokemonByType() {
    const selectedType = document.getElementById('typeFilter').value;
    if (!selectedType) {
        displayPokemonCatalog(allPokemon); // Exibe todos os Pokémon
        return;
    }

    const url = `https://pokeapi.co/api/v2/type/${selectedType}`;
    try {
        const response = await fetch(url);
        const data = await response.json();
        const filteredPokemon = data.pokemon.map(p => ({
            name: p.pokemon.name,
            url: p.pokemon.url
        }));

        const sortedPokemon = filteredPokemon.sort((a, b) => a.name.localeCompare(b.name));
        displayPokemonCatalog(sortedPokemon);
    } catch (error) {
        console.error('Failed to fetch Pokémon by type:', error);
    }
}

// Função para exibir o catálogo de Pokémon (mantida como solicitado)
function displayPokemonCatalog(pokemonList) {
    const catalog = document.getElementById('pokemonCatalog');
    catalog.innerHTML = pokemonList.map(pokemon => 
        `<div class="pokemon-item" onclick="fetchPokemonDetails('${pokemon.name}', '${pokemon.url}')">
            <img id="${pokemon.name}-img" src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${pokemon.url.split("/")[6]}.png" alt="${pokemon.name}">
            <p><strong>${pokemon.name.charAt(0).toUpperCase() + pokemon.name.slice(1)}</strong></p>
        </div>`
    ).join('');
}

// Função assíncrona para buscar os detalhes de um Pokémon (mantida como solicitado)
async function fetchPokemonDetails(pokemonName, pokemonUrl) {
    const url = `https://pokeapi.co/api/v2/pokemon/${pokemonName}`;
    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error('Pokémon not found');
        }
        const pokemon = await response.json();

        // Obtém a evolução do Pokémon
        const evolutionUrl = `https://pokeapi.co/api/v2/pokemon-species/${pokemon.id}/`;
        const evolutionResponse = await fetch(evolutionUrl);
        const evolutionData = await evolutionResponse.json();
        const evolutionChainUrl = evolutionData.evolution_chain.url;

        const evolutionResponseChain = await fetch(evolutionChainUrl);
        const evolutionChain = await evolutionResponseChain.json();

        displayPokemonInDetails(pokemon, pokemonUrl, evolutionChain.chain);
        showTab('details');
    } catch (error) {
        const detailDiv = document.getElementById('pokemonDetail');
        detailDiv.innerHTML = `<p style="color: red;">${error.message}</p>`;
    }
}

function displayPokemonInDetails(pokemon, pokemonUrl, evolutionChain) {
    const detailDiv = document.getElementById('pokemonDetail');
    const imageUrl = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${pokemonUrl.split("/")[6]}.png`;

    let evolutionHTML = '';
    let currentEvolution = evolutionChain;
    while (currentEvolution) {
        evolutionHTML += 
            `<div class="pokemon-evolution" onclick="fetchPokemonDetails('${currentEvolution.species.name}', '${currentEvolution.species.url}')">
                <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${currentEvolution.species.url.split("/")[6]}.png" alt="${currentEvolution.species.name}">
                <p>${currentEvolution.species.name.charAt(0).toUpperCase() + currentEvolution.species.name.slice(1)}</p>
            </div>`;
        currentEvolution = currentEvolution.evolves_to ? currentEvolution.evolves_to[0] : null;
    }

    pokemonDetail.innerHTML = `
        <div class="pokemon-details-container">
            <div class="pokemon-detail-image-container">
                <img src="${imageUrl}" alt="${pokemon.name}" class="pokemon-detail-image">
            </div>
            <div class="pokemon-info-container">
                <h2>${pokemon.name.charAt(0).toUpperCase() + pokemon.name.slice(1)}</h2>
                <p><strong>ID:</strong> ${pokemon.id}</p>
                <p><strong>Type:</strong> ${pokemon.types.map(type => type.type.name).join(', ')}</p>
                <p><strong>Height:</strong> ${pokemon.height / 10} m</p>
                <p><strong>Weight:</strong> ${pokemon.weight / 10} kg</p>
                <p><strong>Habilidades:</strong> ${pokemon.abilities.map(ability => ability.ability.name).join(', ')}</p>
                <p><strong>Categoria:</strong> ${pokemon.forms[0].name}</p>
                <p><strong>Stats:</strong> ${pokemon.stats.map(stat => `<li><strong>${stat.stat.name}:</strong> ${stat.base_stat}</li>`).join('')}</p>
                <div class="pokemon-evolution-chain">
                <h3 class="evo">Evoluções: (clique na imagem para ver detalhes)</h3>
                    ${evolutionHTML}
                </div>
            </div>
        </div>

        <button onclick="showTab('catalog')" class="b-catalogo">Voltar ao Catálogo</button>`;
}

// Inicializa o catálogo ao carregar a página
fetchAllPokemon();
