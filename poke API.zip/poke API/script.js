// Função para buscar o Pokémon
async function fetchPokemon() {
    const pokemonInput = document.getElementById('pokemonInput').value.toLowerCase();
    const url = `https://pokeapi.co/api/v2/pokemon/${pokemonInput}`;

    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error('Pokémon não encontrado');
        }
        const pokemon = await response.json();

        // Agora buscamos a cadeia evolutiva do Pokémon
        const evolutionUrl = `https://pokeapi.co/api/v2/pokemon-species/${pokemon.id}/`;
        const evolutionResponse = await fetch(evolutionUrl);
        const evolutionData = await evolutionResponse.json();
        const evolutionChainUrl = evolutionData.evolution_chain.url;
        
        // Busca a cadeia evolutiva do Pokémon
        const evolutionResponseChain = await fetch(evolutionChainUrl);
        const evolutionChain = await evolutionResponseChain.json();

        // Exibe os detalhes do Pokémon e sua evolução
        displayPokemon(pokemon, evolutionChain.chain);
    } catch (error) {
        displayError(error.message);
    }
}

// Função para exibir o Pokémon e a evolução
function displayPokemon(pokemon, evolutionChain) {
    const pokemonInfo = document.getElementById('pokemonInfo');
    const imageUrl = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${pokemon.id}.png`;

    let evolutionHTML = '';
    let currentEvolution = evolutionChain;
    while (currentEvolution) {
        evolutionHTML += `
            <div class="pokemon-evolution" onclick="fetchPokemonDetails('${currentEvolution.species.name}', '${currentEvolution.species.url}')">
                <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${currentEvolution.species.url.split("/")[6]}.png" alt="${currentEvolution.species.name}">
                <p>${currentEvolution.species.name.charAt(0).toUpperCase() + currentEvolution.species.name.slice(1)}</p>
            </div>
        `;
        currentEvolution = currentEvolution.evolves_to ? currentEvolution.evolves_to[0] : null;
    }

    pokemonInfo.innerHTML = `
        <div class="pokemon-details-container">
            <div class="pokemon-detail-image-container">
                <img src="${imageUrl}" alt="${pokemon.name}" class="pokemon-detail-image">
            </div>
            <div class="pokemon-info-container">
                <h2>${pokemon.name.charAt(0).toUpperCase() + pokemon.name.slice(1)}</h2>
                <p><strong>ID:</strong> ${pokemon.id}</p>
                <p><strong>Type:</strong> ${pokemon.types.map(type => type.type.name).join(', ')}</p>
                <p><strong>Height:</strong> ${pokemon.height / 10} m</p>
                <p><strong>Weight:</strong> ${pokemon.weight / 10} kg</p>
                <p><strong>Habilidades:</strong> ${pokemon.abilities.map(ability => ability.ability.name).join(', ')}</p>
                <p><strong>Categoria:</strong> ${pokemon.forms[0].name}</p>
                <p><strong>Stats:</strong> ${pokemon.stats.map(stat => `<li><strong>${stat.stat.name}:</strong> ${stat.base_stat}</li>`).join('')}</p>
                <div class="pokemon-evolution-chain">
                <h3 class="evo">Evoluções:(clique na imagem para ver detalhes)</h3>
                    ${evolutionHTML}
                </div>
            </div>
        </div>
    `;
}

// Função para exibir mensagem de erro caso não encontre o Pokémon
function displayError(message) {
    const pokemonInfo = document.getElementById('pokemonInfo');
    pokemonInfo.innerHTML = `<p style="color: red;">${message}</p>`;
}

// Função para alternar entre as abas
function showTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    document.getElementById(tabId).classList.add('active');
}

// Função para buscar os detalhes do Pokémon
async function fetchPokemonDetails(pokemonName, pokemonUrl) {
    const url = `https://pokeapi.co/api/v2/pokemon/${pokemonName}`;
    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error('Pokémon não encontrado');
        }
        const pokemon = await response.json();
        const evolutionUrl = `https://pokeapi.co/api/v2/pokemon-species/${pokemon.id}/`;
        const evolutionResponse = await fetch(evolutionUrl);
        const evolutionData = await evolutionResponse.json();
        const evolutionChainUrl = evolutionData.evolution_chain.url;

        // Busca a cadeia evolutiva
        const evolutionResponseChain = await fetch(evolutionChainUrl);
        const evolutionChain = await evolutionResponseChain.json();

        // Exibe os detalhes do Pokémon e da sua evolução
        displayPokemon(pokemon, evolutionChain.chain);
        showTab('details'); // Alterna para a aba de detalhes
    } catch (error) {
        const detailDiv = document.getElementById('pokemonDetail');
        detailDiv.innerHTML = `<p style="color: red;">${error.message}</p>`;
    }
}

// Função para exibir os detalhes de um Pokémon na aba de detalhes
function displayPokemonInDetails(pokemon, evolutionChain) {
    const detailDiv = document.getElementById('pokemonDetail');
    const imageUrl = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${pokemon.id}.png`;

    let evolutionHTML = '';
    let currentEvolution = evolutionChain;
    while (currentEvolution) {
        evolutionHTML += `
            <div class="pokemon-evolution" onclick="fetchPokemonDetails('${currentEvolution.species.name}', '${currentEvolution.species.url}')">
                <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${currentEvolution.species.url.split("/")[6]}.png" alt="${currentEvolution.species.name}">
                <p>${currentEvolution.species.name.charAt(0).toUpperCase() + currentEvolution.species.name.slice(1)}</p>
            </div>
        `;
        currentEvolution = currentEvolution.evolves_to ? currentEvolution.evolves_to[0] : null;
    }

    detailDiv.innerHTML = `
        <h2>${pokemon.name.charAt(0).toUpperCase() + pokemon.name.slice(1)}</h2>
        <img src="${imageUrl}" alt="${pokemon.name}" class="pokemon-detail-image">
        <p><strong>ID:</strong> ${pokemon.id}</p>
        <p><strong>Type:</strong> ${pokemon.types.map(type => type.type.name).join(', ')}</p>
        <p><strong>Height:</strong> ${pokemon.height / 10} m</p>
        <p><strong>Weight:</strong> ${pokemon.weight / 10} kg</p>
        <p><strong>Habilidades:</strong> ${pokemon.abilities.map(ability => ability.ability.name).join(', ')}</p>
        <h3>Stats:</h3>
        <ul>
            ${pokemon.stats.map(stat => `<li><strong>${stat.stat.name}:</strong> ${stat.base_stat}</li>`).join('')}
        </ul>
        <h3>Evolução:</h3>
        <div class="pokemon-evolution-chain">
            ${evolutionHTML}
        </div>
        <button onclick="showTab('catalog')">Voltar ao Catálogo</button>
    `;
}

// Inicializa a busca de Pokémon
document.querySelector('button').addEventListener('click', fetchPokemon);
